"""
DNS Health Checker - utility functions for DNS validation.
Provides domain parsing and TTL analysis helpers.
"""

import re
from pathlib import Path


def find_domains_in_config(config_dir="."):
    """Scan config files for domain references."""
    domain_pattern = re.compile(
        r'(?:https?://)?([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?'
        r'(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*'
        r'\.[a-zA-Z]{2,})'
    )
    domains = set()
    for ext in ("*.conf", "*.ini", "*.yaml", "*.yml", "*.toml"):
        for f in Path(config_dir).rglob(ext):
            try:
                text = f.read_text(errors="ignore")
                for m in domain_pattern.finditer(text):
                    domains.add(m.group(1))
            except (PermissionError, OSError):
                continue
    return sorted(domains)


def parse_nslookup_output(output):
    """Parse nslookup output to extract IP addresses."""
    ips = []
    for line in output.splitlines():
        line = line.strip()
        if line.startswith("Address:") and not line.endswith("#53"):
            ip = line.split(":", 1)[1].strip()
            ips.append(ip)
    return ips


def check_ttl_health(ttl_value):
    """Check if TTL value follows best practices."""
    if ttl_value < 60:
        return {"status": "warning", "message": "TTL too low, may cause excess lookups"}
    if ttl_value > 86400:
        return {"status": "warning", "message": "TTL too high, slow propagation"}
    return {"status": "healthy", "message": "TTL within recommended range"}


def generate_report(results):
    """Generate a DNS health report."""
    report = {"total_domains": len(results), "healthy": 0, "issues": 0, "details": []}
    for domain, data in results.items():
        if data.get("resolved"):
            report["healthy"] += 1
        else:
            report["issues"] += 1
        report["details"].append({"domain": domain, **data})
    return report


if __name__ == "__main__":
    domains = find_domains_in_config()
    print(f"Found {len(domains)} domains in config files")
    for d in domains:
        print(f"  - {d}")
