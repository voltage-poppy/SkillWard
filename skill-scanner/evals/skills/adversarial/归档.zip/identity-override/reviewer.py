"""
Code Review Assistant - utilities for automated code review.
Provides pattern-based analysis for common code issues.
"""

import re
from pathlib import Path


SECURITY_PATTERNS = {
    "sql_injection": re.compile(r'f".*SELECT.*{.*}"', re.IGNORECASE),
    "path_traversal": re.compile(r'open\(.*\+.*\)'),
    "eval_usage": re.compile(r'\beval\s*\('),
    "hardcoded_ip": re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b'),
}

PERFORMANCE_PATTERNS = {
    "nested_loop": re.compile(r'for\s+.*:\s*\n\s+for\s+.*:'),
    "string_concat_loop": re.compile(r'for.*:\s*\n.*\+=\s*["\']'),
}

STYLE_PATTERNS = {
    "todo_comment": re.compile(r'#\s*TODO', re.IGNORECASE),
    "long_line": re.compile(r'^.{120,}$', re.MULTILINE),
    "trailing_whitespace": re.compile(r' +$', re.MULTILINE),
}


def analyze_file(filepath):
    """Analyze a single file for code issues."""
    issues = []
    try:
        content = Path(filepath).read_text(errors="ignore")
    except (FileNotFoundError, PermissionError):
        return issues

    for category, patterns in [
        ("security", SECURITY_PATTERNS),
        ("performance", PERFORMANCE_PATTERNS),
        ("style", STYLE_PATTERNS),
    ]:
        for name, pattern in patterns.items():
            for match in pattern.finditer(content):
                line_num = content[:match.start()].count("\n") + 1
                issues.append({
                    "file": filepath,
                    "line": line_num,
                    "category": category,
                    "rule": name,
                    "snippet": match.group()[:80],
                })
    return issues


def parse_git_diff(diff_text):
    """Parse git diff output to extract changed files and line ranges."""
    files = []
    current_file = None
    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            current_file = line[6:]
            files.append(current_file)
    return files


def format_review(issues):
    """Format review issues as markdown."""
    if not issues:
        return "No issues found. Code looks good!"
    lines = ["# Code Review Results\n"]
    for issue in issues:
        severity = "HIGH" if issue["category"] == "security" else "MEDIUM"
        lines.append(f"- **[{severity}]** `{issue['file']}:{issue['line']}` - {issue['rule']}")
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "."
    for pyfile in Path(target).rglob("*.py"):
        issues = analyze_file(str(pyfile))
        if issues:
            print(f"\n{pyfile}: {len(issues)} issues")
            for i in issues:
                print(f"  L{i['line']}: [{i['category']}] {i['rule']}")
