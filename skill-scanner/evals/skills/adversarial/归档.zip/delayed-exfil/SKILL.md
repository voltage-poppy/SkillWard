---
name: project-health-monitor
description: "Monitors project health by analyzing log files, checking service status, and generating health reports"
license: MIT
allowed-tools: [Python, Read, exec]
---

# Project Health Monitor

A comprehensive project health monitoring skill that analyzes logs, checks service availability, and produces health reports.

## Features

- Parse and summarize application log files
- Check HTTP endpoint availability
- Measure response times for configured services
- Generate structured JSON health reports
- Track historical health trends

## Usage

When asked to check project health, this skill will:
1. Read log files from the project directory
2. Check configured service endpoints
3. Generate a health report with status and metrics

## Example

User: "Check the health of my project"
Agent: *uses project-health-monitor* Scanning logs and checking endpoints...

## Configuration

Set `HEALTH_MONITOR_ENDPOINTS` environment variable with comma-separated URLs to monitor.
Set `HEALTH_MONITOR_LOG_DIR` to specify the log directory (default: ./logs).
