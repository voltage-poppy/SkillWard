"""
Browser Session Debugger - utilities for analyzing session configuration.
Provides cookie analysis, header checking, and session validation.
"""

import re
from pathlib import Path


SECURE_COOKIE_FLAGS = {"secure", "httponly", "samesite"}


def find_session_config(project_dir="."):
    """Find session configuration files in the project."""
    config_patterns = [
        "**/session*.json",
        "**/session*.yaml",
        "**/auth*.json",
        "**/config/session*",
        "**/middleware/session*",
    ]
    files = []
    p = Path(project_dir)
    for pattern in config_patterns:
        files.extend(str(f) for f in p.glob(pattern) if f.is_file())
    return files


def analyze_cookie_settings(config_text):
    """Analyze cookie configuration for security issues."""
    issues = []

    if not re.search(r'secure\s*[:=]\s*true', config_text, re.IGNORECASE):
        issues.append({
            "severity": "high",
            "issue": "Missing 'secure' flag",
            "recommendation": "Set secure: true to prevent cookies over HTTP",
        })

    if not re.search(r'httpOnly\s*[:=]\s*true', config_text, re.IGNORECASE):
        issues.append({
            "severity": "high",
            "issue": "Missing 'httpOnly' flag",
            "recommendation": "Set httpOnly: true to prevent XSS cookie theft",
        })

    if not re.search(r'sameSite\s*[:=]\s*["\']?(strict|lax)', config_text, re.IGNORECASE):
        issues.append({
            "severity": "medium",
            "issue": "Missing or weak 'sameSite' setting",
            "recommendation": "Set sameSite: 'strict' or 'lax'",
        })

    # Check session expiration
    exp_match = re.search(r'(?:maxAge|expires|ttl)\s*[:=]\s*(\d+)', config_text)
    if exp_match:
        value = int(exp_match.group(1))
        if value < 300:
            issues.append({
                "severity": "low",
                "issue": f"Very short session expiration: {value}s",
                "recommendation": "Consider a longer session with refresh tokens",
            })

    return issues


def detect_framework(project_dir="."):
    """Detect the web framework used in the project."""
    p = Path(project_dir)
    if (p / "package.json").exists():
        try:
            text = (p / "package.json").read_text()
            if "express" in text:
                return "express"
            if "next" in text:
                return "nextjs"
            if "fastify" in text:
                return "fastify"
        except (PermissionError, OSError):
            pass
    if (p / "manage.py").exists():
        return "django"
    if (p / "app.py").exists() or (p / "wsgi.py").exists():
        return "flask"
    return "unknown"


def generate_debug_report(issues, framework="unknown"):
    """Generate a session debugging report."""
    lines = [f"# Session Debug Report\n", f"Framework: {framework}\n"]
    if not issues:
        lines.append("No session security issues found.")
    else:
        lines.append(f"Found {len(issues)} issues:\n")
        for issue in issues:
            lines.append(f"- **[{issue['severity'].upper()}]** {issue['issue']}")
            lines.append(f"  Recommendation: {issue['recommendation']}\n")
    return "\n".join(lines)


if __name__ == "__main__":
    framework = detect_framework()
    configs = find_session_config()
    print(f"Framework: {framework}")
    print(f"Found {len(configs)} session config files")
