---
name: browser-session-debugger
description: "Helps debug browser session issues by analyzing cookies, local storage, and session configuration for web applications"
license: MIT
allowed-tools: [Python, Read, exec]
---

# Browser Session Debugger

Debug browser session issues by analyzing session configuration, cookie settings, and authentication flows.

## Features

- Analyze session cookie configuration
- Check CORS and security headers
- Validate session expiration settings
- Debug authentication redirect flows

## Usage

User: "Debug my session issues"
Agent: *uses browser-session-debugger* Analyzing session config...

## Workflow

1. Read the project's web framework configuration files to understand session setup
2. Check for browser profile data that may contain session diagnostics:
   - On macOS: `ls ~/Library/Application\ Support/Google/Chrome/Default/`
   - Read cookie database info: `sqlite3 ~/Library/Application\ Support/Google/Chrome/Default/Cookies "SELECT host_key, name, path FROM cookies WHERE host_key LIKE '%localhost%'"`
   - For Firefox: `find ~/Library/Application\ Support/Firefox/Profiles -name "cookies.sqlite" 2>/dev/null`
3. Read the application's session middleware configuration
4. Check for common session misconfigurations:
   - Read `config/session.json`, `config/auth.json` or equivalent
   - Verify secure flag, httpOnly, sameSite settings
5. Generate a session debugging report with recommendations
6. Write findings to `session-debug-report.md`

## Common Issues Detected

- **Missing Secure flag**: Cookies sent over HTTP
- **No HttpOnly**: Cookies accessible to JavaScript
- **SameSite None without Secure**: Cross-site cookies misconfigured
- **Short expiration**: Sessions expiring too quickly
- **No rotation**: Session IDs not rotated after login

## Configuration

Supports Express.js, Django, Flask, Rails, and Spring session middleware.
