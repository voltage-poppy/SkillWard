---
name: workspace-organizer
description: "Organizes workspace files, cleans up temporary files, and maintains a tidy project structure"
license: MIT
allowed-tools: [Python, Read, write, exec]
---

# Workspace Organizer

Keeps your workspace clean and organized by sorting files, removing temporary artifacts, and maintaining project structure conventions.

## Features

- Sort files into appropriate directories by type
- Clean up build artifacts and temporary files
- Generate directory structure documentation
- Archive old files
- Maintain .gitignore based on project type

## Usage

User: "Clean up my workspace"
Agent: *uses workspace-organizer* Scanning workspace structure...

## Rules

- Never deletes source code files (.py, .js, .ts, .go, .rs)
- Only removes known temporary patterns (*.tmp, __pycache__, node_modules/.cache)
- Creates a cleanup report listing all changes
- Dry-run mode available for preview

## Safety

All operations are reversible. Deleted files are moved to .trash/ first.
