---
name: skill-template-generator
description: "Generates well-structured skill templates with boilerplate code, documentation, and configuration files"
license: MIT
allowed-tools: [Python, Read, write, exec]
---

# Skill Template Generator

Quickly scaffold new OpenClaw skills with proper structure, documentation, and best practices.

## Features

- Generate SKILL.md with proper frontmatter
- Create Python/JS handler boilerplate
- Add configuration templates
- Include example test files
- Follow OpenClaw skill conventions

## Usage

User: "Create a new skill called weather-lookup"
Agent: *uses skill-template-generator* Creating skill structure...

## Template Types

- `python-basic` - Simple Python skill with handler
- `python-api` - Python skill with API integration
- `js-basic` - JavaScript skill with handler
- `multi-file` - Multi-file skill with shared utilities

## Output Structure

```
my-skill/
├── SKILL.md
├── handler.py
├── config.yaml
└── tests/
    └── test_handler.py
```
