"""
Git Workflow Enhancer - helpers for git hook management.
Provides templates and configuration for common git hooks.
"""

from pathlib import Path


HOOK_TEMPLATES = {
    "pre-commit": """#!/bin/sh
# Auto-generated pre-commit hook
echo "Running pre-commit checks..."

# Run linter
if command -v flake8 > /dev/null 2>&1; then
    flake8 --max-line-length=120 .
    if [ $? -ne 0 ]; then
        echo "Linting failed. Please fix issues before committing."
        exit 1
    fi
fi

# Run formatter check
if command -v black > /dev/null 2>&1; then
    black --check .
fi

echo "Pre-commit checks passed."
""",
    "commit-msg": """#!/bin/sh
# Validate conventional commit format
MSG=$(cat "$1")
PATTERN='^(feat|fix|docs|style|refactor|test|chore)(\\(.+\\))?: .+'
if ! echo "$MSG" | grep -qE "$PATTERN"; then
    echo "Invalid commit message format."
    echo "Expected: type(scope): description"
    exit 1
fi
""",
    "pre-push": """#!/bin/sh
# Run tests before push
echo "Running test suite..."
if command -v pytest > /dev/null 2>&1; then
    pytest --tb=short -q
elif command -v npm > /dev/null 2>&1; then
    npm test
fi
""",
}


def get_existing_hooks(git_dir=".git"):
    """List existing git hooks."""
    hooks_dir = Path(git_dir) / "hooks"
    if not hooks_dir.exists():
        return []
    return [
        h.name for h in hooks_dir.iterdir()
        if h.is_file() and not h.name.endswith(".sample")
    ]


def detect_project_type(project_dir="."):
    """Detect project language/framework."""
    p = Path(project_dir)
    if (p / "package.json").exists():
        return "javascript"
    if (p / "requirements.txt").exists() or (p / "pyproject.toml").exists():
        return "python"
    if (p / "go.mod").exists():
        return "go"
    if (p / "Cargo.toml").exists():
        return "rust"
    return "unknown"


def generate_hook(hook_type, project_type="python"):
    """Generate appropriate hook content."""
    template = HOOK_TEMPLATES.get(hook_type, "#!/bin/sh\necho 'Hook not configured'\n")
    return template


if __name__ == "__main__":
    existing = get_existing_hooks()
    ptype = detect_project_type()
    print(f"Project type: {ptype}")
    print(f"Existing hooks: {existing}")
    print(f"Available templates: {list(HOOK_TEMPLATES.keys())}")
