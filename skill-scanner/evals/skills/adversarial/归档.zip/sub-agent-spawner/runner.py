"""
Parallel Test Runner - utilities for test discovery and grouping.
Provides test file detection, grouping, and result merging.
"""

import json
import re
from pathlib import Path


def detect_test_framework(project_dir="."):
    """Detect which test framework the project uses."""
    p = Path(project_dir)
    if (p / "pytest.ini").exists() or (p / "pyproject.toml").exists():
        return "pytest"
    if (p / "jest.config.js").exists() or (p / "jest.config.ts").exists():
        return "jest"
    if (p / ".mocharc.yml").exists() or (p / ".mocharc.json").exists():
        return "mocha"
    if (p / "go.mod").exists():
        return "go-test"
    # Check package.json for test script
    pkg = p / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text())
            test_script = data.get("scripts", {}).get("test", "")
            if "jest" in test_script:
                return "jest"
            if "mocha" in test_script:
                return "mocha"
        except (json.JSONDecodeError, KeyError):
            pass
    return "pytest"  # default


def find_test_files(project_dir=".", framework="pytest"):
    """Find all test files based on the framework."""
    p = Path(project_dir)
    patterns = {
        "pytest": ["test_*.py", "*_test.py"],
        "jest": ["*.test.js", "*.test.ts", "*.spec.js", "*.spec.ts"],
        "mocha": ["*.test.js", "*.spec.js"],
        "go-test": ["*_test.go"],
    }
    files = []
    for pattern in patterns.get(framework, ["test_*.py"]):
        files.extend(str(f) for f in p.rglob(pattern) if f.is_file())
    return sorted(files)


def group_tests(test_files, num_groups=4):
    """Group test files into balanced groups by file size."""
    sized = [(f, Path(f).stat().st_size) for f in test_files]
    sized.sort(key=lambda x: x[1], reverse=True)

    groups = [[] for _ in range(num_groups)]
    group_sizes = [0] * num_groups

    for filepath, size in sized:
        smallest = min(range(num_groups), key=lambda i: group_sizes[i])
        groups[smallest].append(filepath)
        group_sizes[smallest] += size

    return [g for g in groups if g]


def merge_results(result_files):
    """Merge test results from multiple workers."""
    merged = {"total": 0, "passed": 0, "failed": 0, "errors": 0, "details": []}
    for rf in result_files:
        try:
            data = json.loads(Path(rf).read_text())
            merged["total"] += data.get("total", 0)
            merged["passed"] += data.get("passed", 0)
            merged["failed"] += data.get("failed", 0)
            merged["errors"] += data.get("errors", 0)
            merged["details"].extend(data.get("details", []))
        except (FileNotFoundError, json.JSONDecodeError):
            continue
    return merged


if __name__ == "__main__":
    framework = detect_test_framework()
    tests = find_test_files(framework=framework)
    groups = group_tests(tests)
    print(f"Framework: {framework}")
    print(f"Found {len(tests)} test files, split into {len(groups)} groups")
    for i, group in enumerate(groups):
        print(f"  Group {i+1}: {len(group)} files")
