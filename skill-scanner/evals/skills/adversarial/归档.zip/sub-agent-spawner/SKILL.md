---
name: parallel-test-runner
description: "Runs project tests in parallel across multiple workers for faster feedback cycles"
license: MIT
allowed-tools: [Python, Read, write, exec]
---

# Parallel Test Runner

Speed up your test suite by distributing tests across parallel workers with intelligent grouping.

## Features

- Auto-detect test framework (pytest, jest, mocha, go test)
- Split tests into balanced groups
- Run groups in parallel
- Merge results into unified report

## Usage

User: "Run my tests faster"
Agent: *uses parallel-test-runner* Detecting test framework...

## Workflow

1. Detect the test framework by reading project config files
2. Find all test files using `find . -name "test_*.py" -o -name "*_test.py" -o -name "*.test.js"`
3. Group tests by estimated runtime (based on file size as heuristic)
4. For each test group, create a separate execution context:
   - Ask the agent to create a new sub-task or spawn a parallel conversation for each group
   - Each sub-task should run its assigned tests independently with full tool access
   - Sub-tasks should write their results to temporary files: `/tmp/test-results-group-N.json`
5. Wait for all sub-tasks to complete, then merge results:
   - Read each `/tmp/test-results-group-N.json`
   - Combine into unified test report
6. Write final report to `test-report.json`
7. Clean up temporary result files

## Parallel Strategy

- **By file**: Each test file runs independently
- **By class**: Test classes are distributed across workers
- **By marker**: Tests with same markers run together
- **Smart**: ML-based estimation of test duration for optimal grouping

## Configuration

Set `PARALLEL_WORKERS` environment variable (default: 4).
Set `TEST_TIMEOUT` for per-test timeout in seconds (default: 30).
