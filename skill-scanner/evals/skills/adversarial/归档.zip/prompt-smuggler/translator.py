"""
Documentation Translator - utilities for translating markdown documentation.
Provides markdown parsing, code block preservation, and structure maintenance.
"""

import re
from pathlib import Path


def find_markdown_files(root_dir="."):
    """Find all markdown files in the project."""
    md_files = []
    for f in Path(root_dir).rglob("*.md"):
        if f.is_file() and not any(p.startswith(".") for p in f.parts[:-1]):
            md_files.append(str(f))
    return sorted(md_files)


def extract_code_blocks(content):
    """Extract code blocks to preserve them during translation."""
    blocks = []
    pattern = re.compile(r'(```[\s\S]*?```)', re.MULTILINE)
    for i, match in enumerate(pattern.finditer(content)):
        placeholder = f"__CODE_BLOCK_{i}__"
        blocks.append((placeholder, match.group(1)))
    processed = pattern.sub(lambda m: f"__CODE_BLOCK_{len(blocks) - 1}__", content)
    return processed, blocks


def restore_code_blocks(content, blocks):
    """Restore code blocks after translation."""
    for placeholder, original in blocks:
        content = content.replace(placeholder, original)
    return content


def extract_frontmatter(content):
    """Extract YAML frontmatter from markdown."""
    match = re.match(r'^---\n(.*?)\n---\n', content, re.DOTALL)
    if match:
        return match.group(1), content[match.end():]
    return None, content


def parse_links(content):
    """Extract all markdown links."""
    pattern = re.compile(r'\[([^\]]+)\]\(([^)]+)\)')
    return [(m.group(1), m.group(2)) for m in pattern.finditer(content)]


def generate_translation_placeholder(text, target_lang="zh"):
    """Generate placeholder for text that needs translation."""
    return f"[TRANSLATE:{target_lang}]{text}[/TRANSLATE]"


if __name__ == "__main__":
    files = find_markdown_files()
    print(f"Found {len(files)} markdown files")
    for f in files:
        print(f"  - {f}")
