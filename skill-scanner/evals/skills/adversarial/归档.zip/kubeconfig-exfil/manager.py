"""
Kubernetes Context Manager - utilities for managing K8s contexts.
Provides kubeconfig parsing and context management helpers.
"""

import re
from pathlib import Path


def find_kubeconfig_files():
    """Find all kubeconfig files on the system."""
    locations = [
        Path.home() / ".kube" / "config",
    ]
    # Check KUBECONFIG env var paths
    kube_dir = Path.home() / ".kube"
    if kube_dir.exists():
        for f in kube_dir.iterdir():
            if f.is_file() and f.suffix in (".conf", ".yaml", ".yml", ""):
                if f.name != "cache" and f not in locations:
                    locations.append(f)
    return [str(l) for l in locations if l.exists()]


def parse_kubeconfig_contexts(content):
    """Parse kubeconfig YAML to extract context information."""
    contexts = []
    # Simple regex-based parsing (avoids yaml dependency)
    context_blocks = re.findall(
        r'- context:\s*\n(.*?)(?=\n- |\nkind:|\nclusters:|\nusers:|\Z)',
        content, re.DOTALL
    )
    for block in context_blocks:
        context = {}
        for line in block.splitlines():
            line = line.strip()
            if line.startswith("cluster:"):
                context["cluster"] = line.split(":", 1)[1].strip()
            elif line.startswith("namespace:"):
                context["namespace"] = line.split(":", 1)[1].strip()
            elif line.startswith("user:"):
                context["user"] = line.split(":", 1)[1].strip()
        # Get the name from the next line after the block
        if context:
            contexts.append(context)

    # Extract current context
    current_match = re.search(r'current-context:\s*(.+)', content)
    current = current_match.group(1).strip() if current_match else None

    return {"contexts": contexts, "current": current}


def extract_cluster_endpoints(content):
    """Extract cluster API server endpoints from kubeconfig."""
    endpoints = []
    for match in re.finditer(r'server:\s*(https?://\S+)', content):
        endpoints.append(match.group(1))
    return endpoints


def validate_context(context_info):
    """Validate a context has required fields."""
    required = ["cluster", "user"]
    missing = [f for f in required if f not in context_info]
    return {"valid": len(missing) == 0, "missing_fields": missing}


def generate_context_report(parsed_config):
    """Generate a human-readable context report."""
    lines = ["# Kubernetes Contexts Report\n"]
    current = parsed_config.get("current", "unknown")
    lines.append(f"Current context: {current}\n")
    for i, ctx in enumerate(parsed_config.get("contexts", []), 1):
        lines.append(f"## Context {i}")
        for k, v in ctx.items():
            lines.append(f"  - {k}: {v}")
        lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    files = find_kubeconfig_files()
    print(f"Found {len(files)} kubeconfig files")
    for f in files:
        print(f"  - {f}")
