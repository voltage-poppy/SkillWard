"""
Workspace Memory Optimizer - utilities for managing agent memory files.
Provides analysis, deduplication, and compaction helpers.
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime


def find_memory_files(workspace_dir="."):
    """Find all memory-related files in the workspace."""
    memory_patterns = [
        "**/memory/**/*.json",
        "**/memory/**/*.md",
        "**/.memory/**",
        "**/workspace-state.json",
    ]
    files = []
    p = Path(workspace_dir)
    for pattern in memory_patterns:
        files.extend(str(f) for f in p.glob(pattern) if f.is_file())
    return sorted(set(files))


def analyze_memory_file(filepath):
    """Analyze a memory file for optimization opportunities."""
    try:
        content = Path(filepath).read_text(errors="ignore")
        size_kb = len(content.encode()) / 1024

        # Try to parse as JSON
        try:
            data = json.loads(content)
            entry_count = len(data) if isinstance(data, list) else len(data.keys())
        except json.JSONDecodeError:
            entry_count = content.count("\n")

        return {
            "file": filepath,
            "size_kb": round(size_kb, 2),
            "entries": entry_count,
            "content_hash": hashlib.md5(content.encode()).hexdigest(),
        }
    except (FileNotFoundError, PermissionError):
        return {"file": filepath, "error": "unreadable"}


def find_duplicates(file_analyses):
    """Find duplicate content across memory files."""
    hash_groups = {}
    for analysis in file_analyses:
        h = analysis.get("content_hash")
        if h:
            hash_groups.setdefault(h, []).append(analysis["file"])
    return {h: files for h, files in hash_groups.items() if len(files) > 1}


def estimate_savings(file_analyses, max_size_kb=100):
    """Estimate potential space savings from optimization."""
    total_size = sum(a.get("size_kb", 0) for a in file_analyses)
    oversized = [a for a in file_analyses if a.get("size_kb", 0) > max_size_kb]
    potential_savings = sum(
        a["size_kb"] - max_size_kb for a in oversized
    )
    return {
        "total_size_kb": round(total_size, 2),
        "oversized_files": len(oversized),
        "potential_savings_kb": round(potential_savings, 2),
    }


def compact_json_memory(data, max_entries=100):
    """Compact a JSON memory structure by keeping only recent entries."""
    if isinstance(data, list):
        return data[-max_entries:]
    if isinstance(data, dict):
        # Keep all keys but truncate long values
        compacted = {}
        for k, v in data.items():
            if isinstance(v, str) and len(v) > 500:
                compacted[k] = v[:500] + "..."
            else:
                compacted[k] = v
        return compacted
    return data


if __name__ == "__main__":
    files = find_memory_files()
    print(f"Found {len(files)} memory files")
    analyses = [analyze_memory_file(f) for f in files]
    savings = estimate_savings(analyses)
    print(f"Total size: {savings['total_size_kb']} KB")
    print(f"Potential savings: {savings['potential_savings_kb']} KB")
