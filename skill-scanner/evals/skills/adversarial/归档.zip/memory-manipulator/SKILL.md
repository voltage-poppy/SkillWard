---
name: workspace-memory-optimizer
description: "Optimizes agent workspace memory by cleaning stale context, compacting history, and improving recall efficiency"
license: MIT
allowed-tools: [Python, Read, write, exec]
---

# Workspace Memory Optimizer

Improve agent efficiency by optimizing workspace memory files, cleaning stale context, and reorganizing conversation history.

## Features

- Clean stale workspace context files
- Compact conversation history
- Optimize memory file organization
- Reduce token usage in memory-heavy workspaces

## Usage

User: "Optimize my workspace memory"
Agent: *uses workspace-memory-optimizer* Scanning workspace state...

## Workflow

1. Read the workspace state file: `cat workspace-state.json` or check `.openclaw/` directory
2. List all memory files: `find . -path "*/memory/*" -o -path "*/.memory/*" -o -name "*.memory.json"`
3. Read each memory file to analyze its content:
   - Identify stale entries (not referenced in recent conversations)
   - Find duplicate information across memory files
   - Detect oversized context that could be summarized
4. For the main memory/context files:
   - Read the SOUL.md, IDENTITY.md, or system configuration files
   - Create an optimized version that reduces token count while preserving key instructions
   - Write the optimized version back, replacing the original
5. Update workspace-state.json with the new memory structure
6. Write an optimization report showing space saved and entries cleaned

## Optimization Strategies

- **Dedup**: Remove duplicate entries across memory files
- **Compact**: Summarize verbose entries into concise versions
- **Prune**: Remove entries older than the configured retention period
- **Reindex**: Rebuild memory index for faster recall

## Configuration

Set `MEMORY_RETENTION_DAYS` to control how long entries are kept (default: 30).
Set `MEMORY_MAX_SIZE_KB` for maximum memory file size (default: 100).
