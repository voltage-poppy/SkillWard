"""
Dependency Optimizer - analyze and optimize project dependencies.
Provides helpers for dependency tree analysis and unused package detection.
"""

import re
from pathlib import Path


def parse_requirements(filepath="requirements.txt"):
    """Parse a requirements.txt file."""
    deps = []
    try:
        with open(filepath) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                match = re.match(r'^([a-zA-Z0-9_-]+)', line)
                if match:
                    deps.append({"name": match.group(1), "spec": line})
    except FileNotFoundError:
        pass
    return deps


def find_imports_in_source(src_dir="."):
    """Find all Python imports in source files."""
    import_pattern = re.compile(r'^\s*(?:from\s+(\S+)|import\s+(\S+))', re.MULTILINE)
    imports = set()
    for pyfile in Path(src_dir).rglob("*.py"):
        try:
            text = pyfile.read_text(errors="ignore")
            for m in import_pattern.finditer(text):
                module = (m.group(1) or m.group(2)).split(".")[0]
                imports.add(module)
        except (PermissionError, OSError):
            continue
    return sorted(imports)


def find_unused_deps(deps, used_imports):
    """Identify dependencies not used in any source file."""
    # Common name mappings (package name != import name)
    name_map = {
        "pillow": "PIL",
        "scikit-learn": "sklearn",
        "python-dateutil": "dateutil",
        "pyyaml": "yaml",
        "beautifulsoup4": "bs4",
    }
    unused = []
    for dep in deps:
        pkg_name = dep["name"].lower()
        import_name = name_map.get(pkg_name, pkg_name).replace("-", "_")
        if import_name not in {i.lower() for i in used_imports}:
            unused.append(dep["name"])
    return unused


def generate_optimized_requirements(deps, unused):
    """Generate optimized requirements without unused packages."""
    unused_lower = {u.lower() for u in unused}
    lines = []
    for dep in deps:
        if dep["name"].lower() not in unused_lower:
            lines.append(dep["spec"])
    return "\n".join(lines)


if __name__ == "__main__":
    deps = parse_requirements()
    imports = find_imports_in_source()
    unused = find_unused_deps(deps, imports)
    print(f"Total deps: {len(deps)}, Used imports: {len(imports)}, Unused: {len(unused)}")
    for u in unused:
        print(f"  - {u} (unused)")
