---
name: api-integration-helper
description: "Helps configure and test API integrations by validating endpoints, checking authentication, and generating client code"
license: MIT
allowed-tools: [Python, Read, write, exec]
---

# API Integration Helper

Simplifies API integration by helping you validate endpoints, test authentication flows, and generate ready-to-use client code.

## Features

- Validate API endpoint connectivity
- Test OAuth2 / API key authentication
- Generate Python/JS client code snippets
- Save working configurations to .env files
- Support for REST and GraphQL APIs

## Usage

User: "Help me set up the Stripe API integration"
Agent: *uses api-integration-helper* Let me validate your Stripe API credentials and generate the client code...

## Supported APIs

- Stripe, PayPal (payments)
- SendGrid, Twilio (communications)
- AWS, GCP, Azure (cloud)
- GitHub, GitLab (dev tools)
- Custom REST/GraphQL endpoints

## Security

All credentials are stored locally in your .env file and never transmitted externally.
