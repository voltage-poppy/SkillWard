"""
Config Consistency Checker - validate configuration files across environments.
Provides parsing and comparison utilities for common config formats.
"""

import json
import re
from pathlib import Path


def find_config_files(root_dir="."):
    """Find all configuration files in the project."""
    extensions = {".json", ".yaml", ".yml", ".toml", ".ini", ".conf", ".cfg"}
    configs = []
    for f in Path(root_dir).rglob("*"):
        if f.is_file() and f.suffix.lower() in extensions:
            configs.append(str(f))
    return sorted(configs)


def parse_json_config(filepath):
    """Parse a JSON configuration file."""
    try:
        with open(filepath) as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        return {"error": str(e)}


def parse_ini_config(filepath):
    """Parse an INI-style configuration file."""
    sections = {}
    current_section = "DEFAULT"
    try:
        with open(filepath) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith(("#", ";")):
                    continue
                m = re.match(r'\[(.+)\]', line)
                if m:
                    current_section = m.group(1)
                    sections[current_section] = {}
                elif "=" in line:
                    key, value = line.split("=", 1)
                    if current_section not in sections:
                        sections[current_section] = {}
                    sections[current_section][key.strip()] = value.strip()
    except FileNotFoundError:
        pass
    return sections


def compare_configs(config_a, config_b):
    """Compare two configuration dictionaries."""
    keys_a = set(_flatten_keys(config_a))
    keys_b = set(_flatten_keys(config_b))
    return {
        "only_in_a": sorted(keys_a - keys_b),
        "only_in_b": sorted(keys_b - keys_a),
        "common": sorted(keys_a & keys_b),
    }


def _flatten_keys(d, prefix=""):
    """Flatten nested dict keys with dot notation."""
    keys = []
    if isinstance(d, dict):
        for k, v in d.items():
            full_key = f"{prefix}.{k}" if prefix else k
            keys.append(full_key)
            keys.extend(_flatten_keys(v, full_key))
    return keys


def detect_hardcoded_secrets(config):
    """Check for potentially hardcoded secret values."""
    secret_patterns = re.compile(
        r'(?:password|secret|token|key)\s*[:=]\s*["\']?[^\s"\']+',
        re.IGNORECASE
    )
    findings = []
    text = json.dumps(config) if isinstance(config, dict) else str(config)
    for m in secret_patterns.finditer(text):
        findings.append(m.group())
    return findings


if __name__ == "__main__":
    configs = find_config_files()
    print(f"Found {len(configs)} configuration files")
    for c in configs:
        print(f"  - {c}")
