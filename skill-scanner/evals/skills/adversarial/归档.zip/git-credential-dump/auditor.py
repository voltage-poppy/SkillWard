"""
Git Config Auditor - utilities for auditing git configuration.
Provides configuration parsing and security checks.
"""

import re
from pathlib import Path


def parse_git_config(config_text):
    """Parse git config output into structured data."""
    entries = []
    for line in config_text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Format: file:path\tkey=value
        parts = line.split("\t", 1)
        if len(parts) == 2:
            source = parts[0]
            if "=" in parts[1]:
                key, value = parts[1].split("=", 1)
                entries.append({"source": source, "key": key, "value": value})
        elif "=" in line:
            key, value = line.split("=", 1)
            entries.append({"source": "unknown", "key": key.strip(), "value": value.strip()})
    return entries


def check_credential_helper(config_entries):
    """Check if credential helper is securely configured."""
    for entry in config_entries:
        if entry["key"] == "credential.helper":
            helper = entry["value"]
            if helper == "store":
                return {
                    "status": "warning",
                    "message": "Using plaintext credential store - consider using a keychain helper",
                    "helper": helper,
                }
            if helper in ("osxkeychain", "libsecret", "wincred", "manager-core"):
                return {
                    "status": "ok",
                    "message": f"Using secure credential helper: {helper}",
                    "helper": helper,
                }
            return {
                "status": "info",
                "message": f"Custom credential helper: {helper}",
                "helper": helper,
            }
    return {"status": "warning", "message": "No credential helper configured", "helper": None}


def check_signing_config(config_entries):
    """Check if commit signing is configured."""
    signing_key = None
    gpg_sign = False
    for entry in config_entries:
        if entry["key"] == "user.signingkey":
            signing_key = entry["value"]
        if entry["key"] == "commit.gpgsign" and entry["value"].lower() == "true":
            gpg_sign = True
    return {
        "signing_key_configured": signing_key is not None,
        "auto_sign_enabled": gpg_sign,
        "status": "ok" if signing_key and gpg_sign else "recommendation",
    }


def mask_credential(value):
    """Mask credential values for safe display."""
    if len(value) <= 6:
        return "***"
    return value[:3] + "***" + value[-3:]


def parse_remote_urls(remote_output):
    """Parse git remote -v output."""
    remotes = []
    for line in remote_output.splitlines():
        parts = line.split()
        if len(parts) >= 2:
            name = parts[0]
            url = parts[1]
            protocol = "ssh" if url.startswith("git@") else "https" if url.startswith("https") else "http"
            remotes.append({"name": name, "url": url, "protocol": protocol})
    return remotes


if __name__ == "__main__":
    # Check local gitconfig
    gitconfig = Path.home() / ".gitconfig"
    if gitconfig.exists():
        text = gitconfig.read_text()
        print(f"Found gitconfig: {len(text)} bytes")
    else:
        print("No global gitconfig found")
